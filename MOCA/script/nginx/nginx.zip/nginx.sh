#!/bin/bash


build_params="--prefix=/usr/share/nginx --sbin-path=/usr/sbin/nginx --conf-path=/etc/nginx/nginx.conf --pid-path=/run/nginx.pid --http-log-path=/var/log/nginx/access.log --error-log-path=/var/log/nginx/error.log --user=nginx --group=nginx --with-file-aio --without-mail_pop3_module --without-mail_imap_module --without-mail_smtp_module --without-http_split_clients_module --without-http_uwsgi_module --without-http_scgi_module --with-http_ssl_module --with-http_v2_module --with-http_realip_module --with-http_addition_module --with-http_geoip_module --with-http_sub_module --with-http_dav_module --with-http_flv_module --with-http_mp4_module --with-http_gunzip_module --with-http_gzip_static_module --with-http_random_index_module --with-http_secure_link_module --with-http_slice_module --with-http_stub_status_module --with-http_auth_request_module --with-pcre --with-debug"
 			
 			


# Install requirement packet and lib
yum -y install pcre pcre-devel openssl openssl-devel libssl-devl gzip gzip-devel zlib libxml2 libxml2-devel libxslt-devel gd-devel perl-ExtUtils-Embed geoip geoip-devel gperftools-devel gcc make wget

# Download nginx. Current latest stable version is 1.12
wget http://nginx.org/download/nginx-1.12.2.tar.gz
tar -zxvf nginx-1.12.2.tar.gz
cd "nginx-1.12.2"

#Build and deploy
./configure $build_params
make
make install

# Create nginx init script
cd ..
cp nginx.init /etc/init.d/nginx
chmod +x /etc/init.d/nginx

# Create nginx service file 
cp nginx.service /etc/sysconfig/nginx

# Add nginx user
useradd -d /dev/null -c "nginx user" -s /sbin/nologin nginx

# Config logrotate
cp nginx.logrotate /etc/logrotate.d/nginx 

# Copy nginx.conf
cp nginx.conf /etc/nginx/nginx.conf


# Create folder
mkdir /var/log/nginx
mkdir /etc/nginx/conf.d
mkdir /etc/nginx/html 
mkdir /etc/nginx/ssl 
